# Group 4 — 90° 3-dB Hybrid Coupler

F0 = 1.8 GHz; Z0 = 50 Ω; FR-4 εr=4.4; h=1.6 mm; copper t=35 µm; tanδ=0.02.

Initial synthesis:
- 50 Ω: W ≈ 3.083 mm, λg/4 ≈ 22.809 mm
- 35.36 Ω: W ≈ 5.249 mm, λg/4 ≈ 22.296 mm

The included plots are ideal analytical reference plots. Add actual ANSYS Circuit/HFSS results before final submission.
